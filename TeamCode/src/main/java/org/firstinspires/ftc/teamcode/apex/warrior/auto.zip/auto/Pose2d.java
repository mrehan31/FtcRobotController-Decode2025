package org.firstinspires.ftc.teamcode.apex.warrior.auto;

public class Pose2d {
    public double x, y, heading;

    public Pose2d(double x, double y, double heading) {
        this.x = x;
        this.y = y;
        this.heading = heading;
    }
}
